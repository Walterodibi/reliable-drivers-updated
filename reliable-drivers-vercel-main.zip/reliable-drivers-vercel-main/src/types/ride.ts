
export type UrgencyLevel = 'low' | 'medium' | 'high' | 'asap';

export type RideStatus = 'new' | 'pending' | 'completed' | 'cancelled' | 'no-show';

export interface Ride {
  id: string;
  bookingId: string;
  name: string;
  email: string;
  phoneNumber: string;
  date: string;
  time: string;
  timestamp: string;
  pickup: string;
  dropoff: string;
  transmission: string;
  urgency: UrgencyLevel;
  additionalNotes: string;
  status: RideStatus;
  assignedTo: string | null;
  driver: string | null;
  assignmentStatus: string | null;
  assignedAt: string | null;
  completedAt: string | null;
  cost: number | null;
}
