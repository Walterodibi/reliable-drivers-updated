
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { useUser } from "@/context/UserContext";
import { ThemeToggle } from "@/components/ThemeToggle";
import { UserPlus } from "lucide-react";
import { access } from "fs";
import {getRoleLabel} from "@/lib/config/roleLabels";

export default function Login() {
  const { users, setUser } = useUser();
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const [identifier, setIdentifier] = useState(""); // Can be email or username
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  
  // const handleLogin = (e: React.FormEvent) => {
  //   e.preventDefault();
  //   setIsLoading(true);
    
  //   // Simple validation
  //   if (!identifier || !password) {
  //     toast({
  //       variant: "destructive",
  //       title: "Error",
  //       description: "Please fill in all fields",
  //     });
  //     setIsLoading(false);
  //     return;
  //   }
    
  //   // Find the user by email or username (case insensitive for username)
  //   const foundUser = users.find(user => 
  //     (user.email === identifier) || 
  //     (user.username?.toLowerCase() === identifier.toLowerCase())
  //   );
    
  //   // For demo purposes, we're not actually checking passwords
  //   // In a real app, you'd hash and compare passwords
  //   if (foundUser) {
  //     // Simulating network delay
  //     setTimeout(() => {
  //       setUser(foundUser);
  //       toast({
  //         title: "Success",
  //         description: `Welcome back, ${foundUser.name}!`,
  //       });
        
  //       navigate("/");
  //       setIsLoading(false);
  //     }, 1000);
  //   } else {
  //     setTimeout(() => {
  //       toast({
  //         variant: "destructive",
  //         title: "Login failed",
  //         description: "Invalid username/email or password",
  //       });
  //       setIsLoading(false);
  //     }, 1000);
  //   }
  // };
   
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    console.log("🔐 Login attempt started");
 
    if (!identifier || !password) {
      console.warn("⚠️ Missing credentials:", { identifier, password });
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please fill in all fields",
      });
      setIsLoading(false);
      return;
    }
 
    console.log("📤 Sending login request to API...", {
      endpoint: "https://pms.creatixtech.com/api/user/login",
      payload: {
        email: identifier,
        password: "[REDACTED]" // Avoid logging real passwords
      }
    });
 
    try {
      const response = await fetch("https://pms.creatixtech.com/api/user/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: identifier,
          password: password,
        }),
      });
 
      const result = await response.json();
      console.log("📥 Received response from login API:", result);
 
      if (!response.ok) {
        console.error("❌ Login failed with server error:", result?.message);
        throw new Error(result?.message || "Login failed. Please check your credentials.");
      }
 
      const user = {
        id: result.user?.id || "unknown-id",
        firstName: result.user?.firstName || "Unknown",
        email: result.user?.email || identifier,
        phone: result.user?.phone || "",
        userRole: result.user?.userRole || "2", // default to standard
        lastName: result.user?.lastName || "Unknown",
        // username: result.user?.username || "",
        // role: result.user?.role || "standard",

      };
 
      console.log("✅ Login successful. User object constructed:", user);
 
      // if (result.access_token) {
      //   localStorage.setItem("token", result.access_token);
      //   console.log("🔐 Auth token saved to localStorage",);
      //   // console.log(`TOKEN`, access_token);
      // }

      if (result.token) {
        localStorage.setItem("token", result.token);
        console.log("🔐 Auth token saved to localStorage",);
        // console.log(`TOKEN`, access_token);
      }
 
      setUser(user);
 
      toast({
        title: "Success",
        description: `Welcome back, ${user.firstName}!`,
      });
 
      navigate("/");
      console.log("🚀 Navigation to dashboard completed");
    } catch (error: any) {
      console.error("🚫 Login error caught:", error);
      toast({
        variant: "destructive",
        title: "Login failed",
        description: error.message || "Invalid email or password.",
      });
    } finally {
      setIsLoading(false);
      console.log("🔁 Login process completed");
    }
  };
 
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-background">
      <div className="absolute top-4 right-4">
        <ThemeToggle />
      </div>
      
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="space-y-1 text-center">
          <CardTitle className="text-2xl">Ride Dispatcher</CardTitle>
          <CardDescription>
            Enter your credentials to access the dashboard
          </CardDescription>
        </CardHeader>
        
        <form onSubmit={handleLogin}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="identifier">Username or Email</Label>
              <Input 
                id="identifier" 
                type="text" 
                placeholder="username or email"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input 
                id="password" 
                type="password" 
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <p className="text-xs text-muted-foreground">
                {/* For demo: use any password with a valid username or email */}
              </p>
            </div>
          </CardContent>
          
          <CardFooter className="flex flex-col space-y-3">
            <Button 
              type="submit" 
              className="w-full" 
              disabled={isLoading}
            >
              {isLoading ? "Signing in..." : "Sign in"}
            </Button>
            
            <div className="flex w-full">
              <Button 
                type="button" 
                variant="outline" 
                className="w-full"
                onClick={() => navigate("/register")}
              >
                <UserPlus className="mr-2 h-4 w-4" /> Create Account
              </Button>
            </div>
          </CardFooter>
        </form>
      </Card>
      
      <div className="mt-8 text-center text-sm text-muted-foreground">
        <p>Demo Accounts:</p>
        <ul className="mt-2 space-y-1">
          {users.map(user => (
            <li key={user.id}>
              <span 
                className="cursor-pointer hover:underline" 
                onClick={() => setIdentifier(user.firstName || user.email || "")}
              >
                {user.firstName} {getRoleLabel(user.userRole)}: {user.firstName || user.email}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
