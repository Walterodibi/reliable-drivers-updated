
import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useDispatch } from "@/context/DispatchContext";
import { useUser } from "@/context/UserContext";
import { RideCard } from "@/components/RideCard";
import { RideDetailsDialog } from "@/components/RideDetailsDialog";
import { Button } from "@/components/ui/button";
import { Loader2, RefreshCw, Settings, UserCircle, Clock } from "lucide-react";
import { SettingsDialog } from "@/components/SettingsDialog";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Ride } from "@/types/ride";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription, 
  DialogFooter 
} from "@/components/ui/dialog";
import { sheetsApi } from "@/api/sheets";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Navigate, useNavigate } from "react-router-dom";
import { getRoleLabel } from "@/lib/config/roleLabels";


export default function Dashboard() {
  const {
    newRides,
    myAssignedRides,
    allAssignedRides,
    completedRides,
    selectedRideId,
    setSelectedRideId,
    loading,
    refreshRides,
    rides,
    error,
    autoRefreshEnabled,
    toggleAutoRefresh,
    useMockData,
    toggleUseMockData
  } = useDispatch();
  
  const {
    currentUser,
    setUser,
    isAdmin
  } = useUser();
  const [activeTab, setActiveTab] = useState("new");
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isRideDetailsOpen, setIsRideDetailsOpen] = useState(false);
  const [isTestingDialogOpen, setIsTestingDialogOpen] = useState(false);
  const [testResults, setTestResults] = useState<{
    success?: boolean;
    readSuccess?: boolean;
    writeSuccess?: boolean;
    message?: string;
    isLoading?: boolean;
  }>({});

  const Navigate = useNavigate();

  useEffect(() => {
    if (rides.length > 0) {
      handleTestConnection();
    }
  }, [rides.length]);

  const handleRefresh = async () => {
    await refreshRides();
  };

  const handleTestConnection = async () => {
    setIsTestingDialogOpen(true);
    setTestResults({ isLoading: true });
    
    try {
      const results = await sheetsApi.testConnection();
      setTestResults({
        ...results,
        isLoading: false
      });
    } catch (error) {
      setTestResults({
        success: false,
        message: `Failed to test connection: ${error instanceof Error ? error.message : "Unknown error"}`,
        isLoading: false
      });
    }
  };

  const handleRegisterUser = async () => {
    Navigate("/register");
  }

  const selectedRide = rides.find(ride => ride.id === selectedRideId);

  const handleSelectRide = (ride: Ride) => {
    setSelectedRideId(ride.id);
    setIsRideDetailsOpen(true);
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    setUser(null); // if available
    Navigate("/login");
  };

  const assignedRidesToShow = isAdmin() ? allAssignedRides : myAssignedRides;

  // console.log("Ride IDs", newRides.map(r => r.id));
  
  
  return <div className="container mx-auto py-6 space-y-6 max-w-7xl">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Ride Dispatcher Dashboard</h1>
          <p className="text-sm text-muted-foreground">
            {useMockData ? 'Using Mock Data for Development' : 'Connected to Excel Booking Database'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center mr-4 text-sm text-muted-foreground">
            <UserCircle className="mr-1 h-4 w-4" />
            <span>{currentUser.firstName} ({getRoleLabel(currentUser.userRole)})</span>
          </div>
          
          <div className="flex items-center mr-4">
            <div className="flex items-center space-x-2">
              <Switch 
                id="auto-refresh" 
                checked={autoRefreshEnabled}
                onCheckedChange={toggleAutoRefresh}
              />
              <Label htmlFor="auto-refresh" className="flex items-center cursor-pointer">
                <Clock className="h-4 w-4 mr-1" />
                <div className="flex items-center">
                  <span className="text-xs">Auto-refresh</span>
                  <div className={`ml-2 w-2 h-2 rounded-full ${autoRefreshEnabled ? 'bg-green-500 animate-pulse' : 'bg-gray-300'}`}></div>
                </div>
              </Label>
            </div>
          </div>
          
          <div className="flex items-center mr-4">
            <div className="flex items-center space-x-2">
              <Switch 
                id="mock-data" 
                checked={useMockData}
                onCheckedChange={toggleUseMockData}
              />
              <Label htmlFor="mock-data" className="flex items-center cursor-pointer">
                <span className="text-xs">Use Mock Data</span>
                <div className={`ml-2 w-2 h-2 rounded-full ${useMockData ? 'bg-yellow-500' : 'bg-gray-300'}`}></div>
              </Label>
            </div>
          </div>
          
          <ThemeToggle />
          
          <Button variant="outline" onClick={() => setIsSettingsOpen(true)}>
            <Settings className=" h-4 w-4" />
            Settings
          </Button>
          
          <Button variant="outline" onClick={() => handleRegisterUser()} >
            Register
          </Button>

          <Button variant="outline" onClick={() => handleLogout()} >
            Logout
          </Button>
          
          <Button variant="outline" onClick={handleTestConnection} disabled={useMockData}>
            Test Connection
          </Button>
          
          <Button variant="outline" onClick={handleRefresh} disabled={loading}>
            {loading ? <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Loading Data
              </> : <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Refresh Data
              </>}
          </Button>
        </div>
      </div>
      
      {error && !useMockData && <div className="bg-destructive/15 text-destructive p-4 rounded-md">
          <p className="font-medium">Data Connection Error</p>
          <p className="text-sm">{error}</p>
          <p className="text-sm mt-2">
            There was an error loading the Excel data. Try refreshing the page 
            or switch to using mock data for development.
          </p>
        </div>}
      
      <div className="grid grid-cols-1 gap-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full grid grid-cols-3">
            <TabsTrigger value="new">
              New Bookings
              {newRides.length > 0 && <span className="ml-2 bg-primary text-primary-foreground rounded-full px-2 py-0.5 text-xs">
                  {newRides.length}
                </span>}
            </TabsTrigger>
            <TabsTrigger value="assigned">
              {isAdmin() ? 'All Pending' : 'My Pending'}
              {assignedRidesToShow.length > 0 && <span className="ml-2 bg-primary text-primary-foreground rounded-full px-2 py-0.5 text-xs">
                  {assignedRidesToShow.length}
                </span>}
            </TabsTrigger>
            <TabsTrigger value="completed">
              Completed/Cancelled
              {completedRides.length > 0 && <span className="ml-2 bg-primary text-primary-foreground rounded-full px-2 py-0.5 text-xs">
                  {completedRides.length}
                </span>}
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="new" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {newRides.length === 0 ? <div className="col-span-full flex flex-col items-center justify-center h-48 text-center border rounded-lg p-4">
                  <p className="text-muted-foreground">Looks like there's nothing available for now.</p>
                </div> : newRides.map(ride => <RideCard key={ride.id} ride={ride} onSelect={() => handleSelectRide(ride)} isSelected={selectedRideId === ride.id} showAssignButton={true} />)}
            </div>
          </TabsContent>
          
          <TabsContent value="assigned" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {assignedRidesToShow.length === 0 ? <div className="col-span-full flex flex-col items-center justify-center h-48 text-center border rounded-lg p-4">
                  <p className="text-muted-foreground">
                    {isAdmin() ? "No pending bookings found. Keep it up." : "You haven't been assigned any pending bookings."}
                  </p>
                </div> : assignedRidesToShow.map(ride => <RideCard key={ride.id} ride={ride} onSelect={() => handleSelectRide(ride)} isSelected={selectedRideId === ride.id} />)}
            </div>
          </TabsContent>
          
          <TabsContent value="completed" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {completedRides.length === 0 ? <div className="col-span-full flex flex-col items-center justify-center h-48 text-center border rounded-lg p-4">
                  <p className="text-muted-foreground">No completed or cancelled bookings found.</p>
                </div> : completedRides.map(ride => <RideCard key={ride.id} ride={ride} onSelect={() => handleSelectRide(ride)} isSelected={selectedRideId === ride.id} />)}
            </div>
          </TabsContent>
        </Tabs>
      </div>
      
      <Dialog open={isTestingDialogOpen} onOpenChange={setIsTestingDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Excel Data Connection Test</DialogTitle>
            <DialogDescription>
              Testing connection to the Excel booking database.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {testResults.isLoading ? (
              <div className="flex flex-col items-center justify-center p-8 text-center">
                <Loader2 className="h-8 w-8 animate-spin mb-4 text-primary" />
                <p>Testing connection to Excel data...</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Reading data from the Excel file
                </p>
              </div>
            ) : (
              <div className={`rounded-lg p-4 ${testResults.success ? 'bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-900' : 'bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900'}`}>
                <div className="flex items-center mb-2">
                  <div className={`w-3 h-3 rounded-full mr-2 ${testResults.success ? 'bg-green-500' : 'bg-red-500'}`}></div>
                  <h3 className="font-medium">Connection Status: {testResults.success ? 'Successful' : 'Failed'}</h3>
                </div>
                
                <div className="grid grid-cols-2 gap-2 mb-4">
                  <div className="flex items-center">
                    <div className={`w-2 h-2 rounded-full mr-2 ${testResults.readSuccess ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span>READ: {testResults.readSuccess ? 'Success' : 'Failed'}</span>
                  </div>
                  <div className="flex items-center">
                    <div className={`w-2 h-2 rounded-full mr-2 ${testResults.writeSuccess ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span>WRITE: {testResults.writeSuccess ? 'Success' : 'Failed'}</span>
                  </div>
                </div>
                
                <p className="text-sm mt-2">{testResults.message}</p>
              </div>
            )}
          </div>
          
          <DialogFooter className="sm:justify-between">
            <Button 
              variant="secondary" 
              onClick={() => setIsTestingDialogOpen(false)}
              disabled={testResults.isLoading}
            >
              Close
            </Button>
            <Button 
              onClick={handleTestConnection} 
              disabled={testResults.isLoading}
            >
              {testResults.isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Testing...
                </>
              ) : 'Run Test Again'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <SettingsDialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen} />
      
      <RideDetailsDialog ride={selectedRide} open={isRideDetailsOpen} onOpenChange={setIsRideDetailsOpen} />
    </div>;
}
