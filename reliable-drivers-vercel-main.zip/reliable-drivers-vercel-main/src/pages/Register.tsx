
// import { useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
// import { Button } from "@/components/ui/button";
// import { Input } from "@/components/ui/input";
// import { Label } from "@/components/ui/label";
// import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
// import { useToast } from "@/components/ui/use-toast";
// import { useUser, UserRole } from "@/context/UserContext";
// import { ThemeToggle } from "@/components/ThemeToggle";
// import { ChevronLeft } from "lucide-react";

// export default function Register() {
//   const { addUser, isUsernameTaken } = useUser();
//   const { toast } = useToast();
//   const navigate = useNavigate();
  
//   const [name, setName] = useState("");
//   const [username, setUsername] = useState("");
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const [confirmPassword, setConfirmPassword] = useState("");
//   const [role, setRole] = useState<UserRole>("standard");
//   const [isLoading, setIsLoading] = useState(false);
//   const [usernameError, setUsernameError] = useState("");
  
//   const handleUsernameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
//     const value = e.target.value;
//     setUsername(value);
    
//     // Clear previous error
//     setUsernameError("");
    
//     // Check if username is taken (but only if there's a value)
//     if (value && isUsernameTaken(value)) {
//       setUsernameError("This username is already taken");
//     }
//   };
  
//   const handleRegister = (e: React.FormEvent) => {
//     e.preventDefault();
//     setIsLoading(true);
    
//     // Simple validation
//     if (!name || !username || !email || !password || !confirmPassword) {
//       toast({
//         variant: "destructive",
//         title: "Error",
//         description: "Please fill in all fields",
//       });
//       setIsLoading(false);
//       return;
//     }
    
//     if (password !== confirmPassword) {
//       toast({
//         variant: "destructive",
//         title: "Error",
//         description: "Passwords do not match",
//       });
//       setIsLoading(false);
//       return;
//     }
    
//     if (usernameError) {
//       toast({
//         variant: "destructive",
//         title: "Error",
//         description: usernameError,
//       });
//       setIsLoading(false);
//       return;
//     }
    
//     // Simulate network delay
//     setTimeout(() => {
//       try {
//         // Add the new user (in a real app, this would involve server-side validation)
//         addUser({
//           name,
//           username,
//           email,
//           role
//         });
        
//         toast({
//           title: "Account created",
//           description: "Your account has been created successfully!",
//         });
        
//         // Navigate to login page
//         navigate("/login");
//       } catch (error) {
//         toast({
//           variant: "destructive",
//           title: "Registration failed",
//           description: error instanceof Error ? error.message : "An unknown error occurred",
//         });
//       } finally {
//         setIsLoading(false);
//       }
//     }, 1000);
//   };
  
//   return (
//     <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-background">
//       <div className="absolute top-4 right-4">
//         <ThemeToggle />
//       </div>
      
//       <Card className="w-full max-w-md shadow-lg">
//         <CardHeader className="space-y-1 text-center">
//           <CardTitle className="text-2xl">Create Account</CardTitle>
//           <CardDescription>
//             Fill in your details to create a new account
//           </CardDescription>
//         </CardHeader>
        
//         <form onSubmit={handleRegister}>
//           <CardContent className="space-y-4">
//             <div className="space-y-2">
//               <Label htmlFor="name">Full Name</Label>
//               <Input 
//                 id="name" 
//                 value={name}
//                 onChange={(e) => setName(e.target.value)}
//                 placeholder="John Doe"
//                 required
//               />
//             </div>
            
//             <div className="space-y-2">
//               <Label htmlFor="username">Username</Label>
//               <Input 
//                 id="username" 
//                 value={username}
//                 onChange={handleUsernameChange}
//                 placeholder="johndoe"
//                 required
//                 className={usernameError ? "border-red-500" : ""}
//               />
//               {usernameError && (
//                 <p className="text-xs text-red-500">{usernameError}</p>
//               )}
//             </div>
            
//             <div className="space-y-2">
//               <Label htmlFor="email">Email</Label>
//               <Input 
//                 id="email" 
//                 type="email" 
//                 value={email}
//                 onChange={(e) => setEmail(e.target.value)}
//                 placeholder="john.doe@example.com"
//                 required
//               />
//             </div>
            
//             <div className="space-y-2">
//               <Label htmlFor="password">Password</Label>
//               <Input 
//                 id="password" 
//                 type="password" 
//                 value={password}
//                 onChange={(e) => setPassword(e.target.value)}
//                 placeholder="••••••••"
//                 required
//               />
//             </div>
            
//             <div className="space-y-2">
//               <Label htmlFor="confirmPassword">Confirm Password</Label>
//               <Input 
//                 id="confirmPassword" 
//                 type="password" 
//                 value={confirmPassword}
//                 onChange={(e) => setConfirmPassword(e.target.value)}
//                 placeholder="••••••••"
//                 required
//               />
//             </div>
            
//             <div className="space-y-2">
//               <Label>Account Type</Label>
//               <RadioGroup 
//                 value={role}
//                 onValueChange={(value) => setRole(value as UserRole)}
//                 className="flex space-x-4"
//               >
//                 <div className="flex items-center space-x-2">
//                   <RadioGroupItem value="standard" id="standard" />
//                   <Label htmlFor="standard">Standard User</Label>
//                 </div>
//                 <div className="flex items-center space-x-2">
//                   <RadioGroupItem value="admin" id="admin" />
//                   <Label htmlFor="admin">Administrator</Label>
//                 </div>
//               </RadioGroup>
//             </div>
//           </CardContent>
          
//           <CardFooter className="flex flex-col space-y-3">
//             <Button 
//               type="submit" 
//               className="w-full" 
//               disabled={isLoading || !!usernameError}
//             >
//               {isLoading ? "Creating Account..." : "Create Account"}
//             </Button>
            
//             <Button 
//               type="button" 
//               variant="outline" 
//               className="w-full"
//               onClick={() => navigate("/login")}
//             >
//               <ChevronLeft className="mr-2 h-4 w-4" /> Back to Login
//             </Button>
//           </CardFooter>
//         </form>
//       </Card>
//     </div>
//   );
// }

import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/components/ui/use-toast";
import { ThemeToggle } from "@/components/ThemeToggle";
import { ChevronLeft } from "lucide-react";

type FormData = {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  password: string;
  // confirmPassword: string;
  userRole: "admin" | "standard";
};

export default function Register() {
  const { toast } = useToast();
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    watch,
    setError,
    setValue, 
    formState: { errors, isSubmitting }
  } = useForm<FormData>({
    defaultValues: { userRole: "standard" }
  });


  const onSubmit = async (data: FormData) => {
    const roleValue = data.userRole === "admin" ? "1" : "2";
    // if (data.password !== data.confirmPassword) {
    //   setError("confirmPassword", { message: "Passwords do not match" });
    //   return;
    // }

    try {
      await axios.post("https://pms.creatixtech.com/api/user/register", {
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        password: data.password,
        userRole: roleValue,
        phone: data.phone
      });

      toast({
        title: "Account created",
        description: "Your account has been created successfully!",
      });
      navigate("/login");
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Registration failed",
        description: error.response?.data?.message || "Something went wrong",
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-background">
      <div className="absolute top-4 right-4">
        <ThemeToggle />
      </div>

      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="space-y-1 text-center">
          <CardTitle className="text-2xl">Create Account</CardTitle>
          <CardDescription>
            Fill in your details to create a new account
          </CardDescription>
        </CardHeader>

        <form onSubmit={handleSubmit(onSubmit)}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name</Label>
              <Input id="firstName" placeholder="John Doe" {...register("firstName", { required: "First Name is required" })} />
              {errors.firstName && <p className="text-xs text-red-500">{errors.firstName.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name</Label>
              <Input id="lastName" placeholder="johndoe" {...register("lastName", { required: "Last Name is required" })} />
              {errors.lastName && <p className="text-xs text-red-500">{errors.lastName.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="john@example.com" {...register("email", { required: "Email is required" })} />
              {errors.email && <p className="text-xs text-red-500">{errors.email.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input id="phone" type="text" placeholder="123456.." {...register("phone", { required: "Number is required" })} />
              {errors.phone && <p className="text-xs text-red-500">{errors.phone.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input id="password" type="password" placeholder="••••••••" {...register("password", { required: "Password is required" })} />
              {errors.password && <p className="text-xs text-red-500">{errors.password.message}</p>}
            </div>

            {/* <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <Input id="confirmPassword" type="password" placeholder="••••••••" {...register("confirmPassword", { required: "Confirm your password" })} />
              {errors.confirmPassword && <p className="text-xs text-red-500">{errors.confirmPassword.message}</p>}
            </div> */}

            <div className="space-y-2">
              <Label>Account Type</Label>
              <RadioGroup 
              className="flex" 
              defaultValue="standard" 
              onValueChange={(val: "admin" | "standard") => setValue("userRole", val)}
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="standard" id="standard" />
                  <Label htmlFor="standard">Standard User</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="admin" id="admin" />
                  <Label htmlFor="admin">Administrator</Label>
                </div>
              </RadioGroup>
            </div>
          </CardContent>

          <CardFooter className="flex flex-col space-y-3">
            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? "Creating Account..." : "Create Account"}
            </Button>

            <Button type="button" variant="outline" className="w-full" onClick={() => navigate("/")}>
              <ChevronLeft className="mr-2 h-4 w-4" /> Back to Dashboard
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
} 