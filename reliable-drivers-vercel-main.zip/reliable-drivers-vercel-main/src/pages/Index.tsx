
import { DispatchProvider } from "@/context/DispatchContext";
import { RoleSelector } from "@/components/RoleSelector";
import { useUser } from "@/context/UserContext";
import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import Dashboard from "./Dashboard";
import { sheetsApi } from "@/api/sheets";
import { useToast } from "@/components/ui/use-toast";

const Index = () => {
  const { isDarkMode, currentUser } = useUser();
  const [isAuthenticated, setIsAuthenticated] = useState(true);
  const [connectionTested, setConnectionTested] = useState(false);
  const { toast } = useToast();
  
  // Check if user is authenticated
  useEffect(() => {
    // If currentUser has an id, they're authenticated
    // This is a simple check for this demo app
    const isAuth = !!currentUser.id;
    setIsAuthenticated(isAuth);
    
    // Run connection test when user logs in and show welcome toast
    if (isAuth && !connectionTested) {
      const runConnectionTest = async () => {
        try {
          const result = await sheetsApi.testConnection();
          
          if (result.success) {
            // Show a toast notification about the successful connection
            toast({
              title: "Connected to Booking Sheet",
              description: "Successfully loaded booking data from Excel file.",
              duration: 5000,
            });
          } else {
            // Show error toast
            toast({
              title: "Connection Test Failed",
              description: result.message,
              variant: "destructive"
            });
          }
          
          setConnectionTested(true);
        } catch (error) {
          console.error("Connection test failed:", error);
          toast({
            title: "Connection Test Error",
            description: `Failed to test connection: ${error instanceof Error ? error.message : "Unknown error"}`,
            variant: "destructive"
          });
        }
      };
      
      runConnectionTest();
    }
  }, [currentUser, toast, connectionTested]);
  
  // Apply dark mode class to the document
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [isDarkMode]);
  
  // If not authenticated, redirect to login
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  return (
    <DispatchProvider>
      <div className="fixed top-4 right-4 z-10">
        <RoleSelector />
      </div>
      <Dashboard />
    </DispatchProvider>
  );
};

export default Index;
