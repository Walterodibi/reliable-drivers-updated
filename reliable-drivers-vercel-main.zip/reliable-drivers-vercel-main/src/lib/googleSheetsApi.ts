
import { Ride, RideStatus } from "@/types/ride";
import { google } from "googleapis";
import credentials from "./config/credentials.json";

// Sheet configuration
const SHEET_ID = "1tXpIX3SJsRXexVd4xp83uPVTyVATiPvBjKLrltA4XUA";
const SHEET_NAME = "Booking_database";

// Initialize Google Sheets API client
async function getAuthClient() {
  try {
    const auth = new google.auth.JWT({
      email: credentials.client_email,
      key: credentials.private_key,
      scopes: ["https://www.googleapis.com/auth/spreadsheets"],
    });

    await auth.authorize();
    return auth;
  } catch (error) {
    console.error("Authentication error:", error);
    throw new Error(
      `Failed to authenticate with Google Sheets API: ${
        error instanceof Error ? error.message : String(error)
      }`
    );
  }
}

export async function fetchRidesFromSheet(): Promise<Ride[]> {
  try {
    console.log("Fetching rides directly from Google Sheets API...");
    const auth = await getAuthClient();
    const sheets = google.sheets({ version: "v4", auth });

    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SHEET_ID,
      range: `${SHEET_NAME}!A2:T`,
    });

    const rows = response.data.values || [];
    const rides = rows
      .map(mapRowToRide)
      .filter((ride): ride is Ride => ride !== null);

    console.log(`Retrieved ${rides.length} rides from sheet`);
    return rides;
  } catch (error) {
    console.error("Error fetching rides from sheet:", error);
    throw new Error(
      `Failed to fetch rides from sheet: ${
        error instanceof Error ? error.message : String(error)
      }`
    );
  }
}

// Map row data from spreadsheet to Ride object
function mapRowToRide(row: any[]): Ride | null {
  if (!row || row.length < 15) return null;

  const bookingId = row[0]?.toString() || "";

  return {
    id: bookingId,
    bookingId: bookingId,
    name: row[2]?.toString() || "",
    email: row[3]?.toString() || "",
    phoneNumber: row[4]?.toString() || "",
    date: row[6]?.toString() || "",
    time: row[7]?.toString() || "",
    pickup: row[8]?.toString() || "",
    dropoff: row[9]?.toString() || "",
    transmission: row[10]?.toString() || "",
    urgency: row[11]?.toString() || "medium",
    additionalNotes: row[12]?.toString() || "",
    status: (row[13]?.toString() || "new") as RideStatus,
    assignedTo: row[14]?.toString() || null,
    driver: row[15]?.toString() || null,
    assignmentStatus: row[16]?.toString() || "unassigned",
    assignedAt: row[17]?.toString() || null,
    completedAt: row[18]?.toString() || null,
    cost: row[19] ? Number(row[19]) : null,
  };
}

// Function to test connection
export async function testSheetsConnection() {
  try {
    console.log("Testing direct Google Sheets connection...");
    const auth = await getAuthClient();
    const sheets = google.sheets({ version: "v4", auth });
    
    // Simple read test
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SHEET_ID,
      range: `${SHEET_NAME}!A1:C1`,
    });
    
    return {
      success: true,
      readSuccess: true,
      message: "Successfully connected to Google Sheets API"
    };
  } catch (error) {
    console.error("Sheet connection test failed:", error);
    return {
      success: false,
      readSuccess: false,
      message: `Connection test failed: ${error instanceof Error ? error.message : String(error)}`
    };
  }
}

// Function to update a ride's status
export async function updateRideStatus(rideId: string, status: RideStatus): Promise<Ride> {
  try {
    const auth = await getAuthClient();
    const sheets = google.sheets({ version: "v4", auth });
    
    // First, get all rides to find the one to update
    const allRides = await fetchRidesFromSheet();
    const rideIndex = allRides.findIndex(ride => ride.id === rideId);
    
    if (rideIndex === -1) {
      throw new Error(`Ride with ID ${rideId} not found`);
    }
    
    // Get the row number (adding 2 because row 1 is header and sheet is 1-indexed)
    const rowNumber = rideIndex + 2;
    
    // Update the ride locally
    const updatedRide = {
      ...allRides[rideIndex],
      status: status,
      completedAt: ["completed", "cancelled", "no-show"].includes(status) 
        ? new Date().toISOString() 
        : allRides[rideIndex].completedAt
    };
    
    // Prepare the row data
    const rowData = [
      updatedRide.id,
      updatedRide.bookingId,
      updatedRide.name,
      updatedRide.email,
      updatedRide.phoneNumber,
      "",
      updatedRide.date,
      updatedRide.time,
      updatedRide.pickup,
      updatedRide.dropoff,
      updatedRide.transmission,
      updatedRide.urgency,
      updatedRide.additionalNotes,
      updatedRide.status,
      updatedRide.assignedTo || "",
      updatedRide.driver || "",
      updatedRide.assignmentStatus || "",
      updatedRide.assignedAt || "",
      updatedRide.completedAt || "",
      updatedRide.cost || ""
    ];
    
    // Update the spreadsheet
    await sheets.spreadsheets.values.update({
      spreadsheetId: SHEET_ID,
      range: `${SHEET_NAME}!A${rowNumber}:T${rowNumber}`,
      valueInputOption: "RAW",
      requestBody: {
        values: [rowData]
      }
    });
    
    return updatedRide;
  } catch (error) {
    console.error("Error updating ride status:", error);
    throw new Error(`Failed to update ride status: ${error instanceof Error ? error.message : String(error)}`);
  }
}

// Function to assign a ride to a user
export async function assignRideToUser(rideId: string, userId: string): Promise<Ride> {
  try {
    const auth = await getAuthClient();
    const sheets = google.sheets({ version: "v4", auth });
    
    // First, get all rides to find the one to update
    const allRides = await fetchRidesFromSheet();
    const rideIndex = allRides.findIndex(ride => ride.id === rideId);
    
    if (rideIndex === -1) {
      throw new Error(`Ride with ID ${rideId} not found`);
    }
    
    // Get the row number (adding 2 because row 1 is header and sheet is 1-indexed)
    const rowNumber = rideIndex + 2;
    
    // Update the ride locally
    const updatedRide = {
      ...allRides[rideIndex],
      assignedTo: userId,
      assignmentStatus: "assigned",
      assignedAt: new Date().toISOString(),
      status: "pending" as RideStatus
    };
    
    // Prepare the row data
    const rowData = [
      updatedRide.id,
      updatedRide.bookingId,
      updatedRide.name,
      updatedRide.email,
      updatedRide.phoneNumber,
      "",
      updatedRide.date,
      updatedRide.time,
      updatedRide.pickup,
      updatedRide.dropoff,
      updatedRide.transmission,
      updatedRide.urgency,
      updatedRide.additionalNotes,
      updatedRide.status,
      updatedRide.assignedTo || "",
      updatedRide.driver || "",
      updatedRide.assignmentStatus || "",
      updatedRide.assignedAt || "",
      updatedRide.completedAt || "",
      updatedRide.cost || ""
    ];
    
    // Update the spreadsheet
    await sheets.spreadsheets.values.update({
      spreadsheetId: SHEET_ID,
      range: `${SHEET_NAME}!A${rowNumber}:T${rowNumber}`,
      valueInputOption: "RAW",
      requestBody: {
        values: [rowData]
      }
    });
    
    return updatedRide;
  } catch (error) {
    console.error("Error assigning ride:", error);
    throw new Error(`Failed to assign ride: ${error instanceof Error ? error.message : String(error)}`);
  }
}

// Function to update a ride's cost
export async function updateRideCost(rideId: string, cost: number): Promise<Ride> {
  try {
    const auth = await getAuthClient();
    const sheets = google.sheets({ version: "v4", auth });
    
    // First, get all rides to find the one to update
    const allRides = await fetchRidesFromSheet();
    const rideIndex = allRides.findIndex(ride => ride.id === rideId);
    
    if (rideIndex === -1) {
      throw new Error(`Ride with ID ${rideId} not found`);
    }
    
    // Get the row number (adding 2 because row 1 is header and sheet is 1-indexed)
    const rowNumber = rideIndex + 2;
    
    // Update the ride locally
    const updatedRide = {
      ...allRides[rideIndex],
      cost: cost
    };
    
    // Prepare the row data
    const rowData = [
      updatedRide.id,
      updatedRide.bookingId,
      updatedRide.name,
      updatedRide.email,
      updatedRide.phoneNumber,
      "",
      updatedRide.date,
      updatedRide.time,
      updatedRide.pickup,
      updatedRide.dropoff,
      updatedRide.transmission,
      updatedRide.urgency,
      updatedRide.additionalNotes,
      updatedRide.status,
      updatedRide.assignedTo || "",
      updatedRide.driver || "",
      updatedRide.assignmentStatus || "",
      updatedRide.assignedAt || "",
      updatedRide.completedAt || "",
      updatedRide.cost || ""
    ];
    
    // Update the spreadsheet
    await sheets.spreadsheets.values.update({
      spreadsheetId: SHEET_ID,
      range: `${SHEET_NAME}!A${rowNumber}:T${rowNumber}`,
      valueInputOption: "RAW",
      requestBody: {
        values: [rowData]
      }
    });
    
    return updatedRide;
  } catch (error) {
    console.error("Error updating ride cost:", error);
    throw new Error(`Failed to update ride cost: ${error instanceof Error ? error.message : String(error)}`);
  }
}
