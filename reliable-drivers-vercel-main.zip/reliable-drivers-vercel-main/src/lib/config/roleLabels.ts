export const getRoleLabel = (role: string) => {
    if (role === "1") return "Admin";
    if (role === "2") return "Standard";
    return "Unknown";
  };
  