
import * as XLSX from 'xlsx';
import { Ride } from '@/types/ride';

// Path to the Excel file in the project
const EXCEL_FILE_PATH = '/src/lib/config/ReliableDrivers Booking Database.xlsx';

// Function to read the Excel file and convert to Rides
export async function readExcelFile(): Promise<Ride[]> {
  try {
    // Fetch the Excel file
    const response = await fetch(EXCEL_FILE_PATH);
    const arrayBuffer = await response.arrayBuffer();
    
    // Parse the Excel file
    const workbook = XLSX.read(arrayBuffer, { type: 'array' });
    
    // Get the first sheet
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    
    // Convert to JSON
    const jsonData = XLSX.utils.sheet_to_json(worksheet);
    
    // Map to Ride objects
    const rides: Ride[] = jsonData.map((row: any) => {
      // Handle Excel dates that may come as numbers
      let dateString = row.Date;
      let timeString = row.Time;

      // If date is a number (Excel serial date), convert to string
      if (typeof row.Date === 'number') {
        // Convert Excel date number to a JS Date
        const excelDate = XLSX.SSF.parse_date_code(row.Date);
        dateString = `${excelDate.y}-${String(excelDate.m).padStart(2, '0')}-${String(excelDate.d).padStart(2, '0')}`;
      }

      // If time is a number (Excel serial time), convert to string
      if (typeof row.Time === 'number') {
        // Convert Excel time number (fraction of day) to hours and minutes
        const totalMinutes = Math.round(row.Time * 24 * 60);
        const hours = Math.floor(totalMinutes / 60);
        const minutes = totalMinutes % 60;
        timeString = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
      }

      // Use the raw urgency value from the sheet, defaulting to medium if not present
      const urgencyVal = row.Urgency || 'medium';

      // Use Booking_id as both id and bookingId
      const bookingId = row.Booking_id || row.BookingID || '';

      return {
        id: bookingId,
        bookingId: bookingId,
        name: row.CustomerName || row.Name || '',
        email: row.Email || '',
        phoneNumber: row.PhoneNumber || row.Phone || '',
        date: dateString || new Date().toISOString().split('T')[0],
        time: timeString || '12:00',
        pickup: row.PickupLocation || row.Pickup || '',
        dropoff: row.DropoffLocation || row.Dropoff || '',
        transmission: row.Transmission || 'Automatic',
        urgency: urgencyVal as any,
        additionalNotes: row.Notes || row.AdditionalNotes || '',
        status: (row.Status || 'new') as any,
        assignedTo: row.AssignedTo || null,
        driver: row.Driver || null,
        assignmentStatus: row.AssignmentStatus || 'unassigned',
        assignedAt: row.AssignedAt || null,
        completedAt: row.CompletedAt || null,
        cost: row.Cost ? Number(row.Cost) : null,
      };
    });
    
    console.log(`Loaded ${rides.length} rides from Excel file`);
    return rides;
  } catch (error) {
    console.error('Error reading Excel file:', error);
    return [];
  }
}

// Store data in-memory for the current session
let inMemoryRides: Ride[] = [];

// Save ride data to in-memory storage
export function saveRideData(rides: Ride[]): void {
  inMemoryRides = [...rides];
}

// Update a single ride in in-memory storage
export function updateRide(updatedRide: Ride): Ride {
  const index = inMemoryRides.findIndex(ride => ride.id === updatedRide.id);
  
  if (index !== -1) {
    inMemoryRides[index] = updatedRide;
  } else {
    inMemoryRides.push(updatedRide);
  }
  
  return updatedRide;
}

// Get all rides from in-memory storage
export function getAllRides(): Ride[] {
  return inMemoryRides;
}

// Find a ride by ID
export function findRideById(id: string): Ride | undefined {
  return inMemoryRides.find(ride => ride.id === id);
}
