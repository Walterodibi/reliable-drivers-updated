import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useUser, UserRole } from "@/context/UserContext";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/components/ui/use-toast";
import { UserCircle, UserPlus, Trash2 } from "lucide-react";
import axios from "axios";
import { getRoleLabel } from "@/lib/config/roleLabels";
interface UserManagementDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}
 
export function UserManagementDialog({ open, onOpenChange }: UserManagementDialogProps) {
  const { users, addUser, removeUser, currentUser, isAdmin } = useUser();
  const { toast } = useToast();
 
  const [newUserName, setNewUserName] = useState("");
  const [newUserEmail, setNewUserEmail] = useState("");
  const [newUserRole, setNewUserRole] = useState<UserRole>("standard");
  const [newUsers,setNewUsers]=useState([]);
  const token=localStorage.getItem("token");
 
const fetchUsers = async () => {
  try {
    const response = await axios.get("https://pms.creatixtech.com/api/users", {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });
    console.log("Fetched users:", response.data);
    setNewUsers(response.data.users);
  } catch (err: unknown) {
    console.error("Error fetching users:", err);
  }
};
 
 
 
useEffect(()=>{
  fetchUsers();
},[])
 
 
 
 
 
  // Only admin users can use this dialog
  if (!isAdmin()) return null;
 
 
 
 
 
 
 
  const handleAddUser = () => {
    if (!newUserName || !newUserEmail) {
      toast({
        variant: "destructive",
        title: "Invalid Input",
        description: "Please fill in all required fields"
      });
      return;
    }
   
    addUser({
      firstName: newUserName,
      email: newUserEmail,
      userRole: newUserRole
    });
   
    // Reset form
    setNewUserName("");
    setNewUserEmail("");
    setNewUserRole("standard");
  };
 
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <UserCircle className="mr-2 h-5 w-5" />
            User Management
          </DialogTitle>
          <DialogDescription>
            Edit or remove users from the system. Only administrators can manage users.
          </DialogDescription>
        </DialogHeader>
       
        <div className="flex-grow overflow-auto py-4">
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium">Current Users</h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>First Name</TableHead>
                    <TableHead>Last Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Role</TableHead>
                    {/* <TableHead className="w-[100px]">Actions</TableHead> */}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {newUsers?.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.firstName}</TableCell>
                      <TableCell className="font-medium">{user.lastName}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <div className="capitalize">{getRoleLabel(user.userRole)}</div>
                      </TableCell>
                      <TableCell>
                        {user.id !== currentUser.id ? (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeUser(user.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        ) : (
                          <span className="text-xs text-muted-foreground">Current</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
           
            <Separator />
           
            {/* <div>
              <h3 className="text-lg font-medium flex items-center mb-4">
                <UserPlus className="mr-2 h-5 w-5" />
                Add New User
              </h3>
             
              <div className="grid gap-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">Name</Label>
                    <Input
                      id="firstName"
                      value={newUserName}
                      onChange={(e) => setNewUserName(e.target.value)}
                    />
                  </div>
                 
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={newUserEmail}
                      onChange={(e) => setNewUserEmail(e.target.value)}
                    />
                  </div>
                </div>
 
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      value={newUserName}
                      onChange={(e) => setNewUserName(e.target.value)}
                    />
                  </div>
                 
                  <div className="space-y-2">
                    <Label htmlFor="email">Phone</Label>
                    <Input
                      id="email"
                      type="email"
                      value={newUserEmail}
                      onChange={(e) => setNewUserEmail(e.target.value)}
                    />
                  </div>
                </div>
               
                <div className="space-y-2">
                  <Label htmlFor="role">Role</Label>
                  <Select
                    value={newUserRole}
                    onValueChange={(value) => setNewUserRole(value as UserRole)}
                  >
                    <SelectTrigger id="role">
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">Administrator</SelectItem>
                      <SelectItem value="standard">Standard User</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div> */}
          </div>
        </div>
       
        <DialogFooter>
          {/* <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleAddUser}>
            Add User
          </Button> */}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}