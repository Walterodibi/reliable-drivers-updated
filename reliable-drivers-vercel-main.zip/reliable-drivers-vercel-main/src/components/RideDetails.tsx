
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { useDispatch } from "@/context/DispatchContext";
import { Ride, RideStatus, UrgencyLevel } from "@/types/ride";
import { CalendarDays, Clock, Mail, MapPin, Phone, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/components/ui/use-toast";

interface RideDetailsProps {
  ride: Ride;
  showCostField?: boolean;
}

export function RideDetails({ ride, showCostField = false }: RideDetailsProps) {
  const { updateStatus, updateRideCost } = useDispatch();
  const { toast } = useToast();
  const [cost, setCost] = useState<string>(ride.cost?.toString() || "");

  const getUrgencyColor = (urgency: UrgencyLevel) => {
    switch (urgency) {
      case "low":
        return "bg-urgent-low";
      case "medium":
        return "bg-urgent-medium";
      case "high":
        return "bg-urgent-high";
      default:
        return "bg-urgent-low";
    }
  };

  const handleStatusChange = (value: string) => {
    updateStatus(ride.id, value as RideStatus);
  };
  
  const handleSendCost = () => {
    const costValue = parseFloat(cost);
    if (isNaN(costValue) || costValue <= 0) {
      toast({
        variant: "destructive",
        title: "Invalid cost",
        description: "Please enter a valid cost value."
      });
      return;
    }
    
    updateRideCost(ride.id, costValue);
    toast({
      title: "Cost updated",
      description: `Cost for ride ${ride.bookingId} has been updated.`
    });
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl">Booking #{ride.bookingId}</CardTitle>
          <Badge className={cn(getUrgencyColor(ride.urgency), "text-white")}>
            {ride.urgency.charAt(0).toUpperCase() + ride.urgency.slice(1)} Priority
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="flex-grow overflow-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Customer Information</h3>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">{ride.name}</span>
              </div>
              
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <a href={`mailto:${ride.email}`} className="text-blue-600 hover:underline">
                  {ride.email}
                </a>
              </div>
              
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-muted-foreground" />
                <a href={`tel:${ride.phoneNumber}`} className="text-blue-600 hover:underline">
                  {ride.phoneNumber}
                </a>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Ride Details</h3>
            
            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <Badge variant="outline" className="mt-0.5">When</Badge>
                <div className="flex flex-col">
                  <div className="flex items-center gap-1">
                    <CalendarDays className="h-3 w-3" />
                    <span>{ride.date}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    <span>{ride.time}</span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-start gap-2">
                <Badge variant="outline" className="mt-0.5">Transmission</Badge>
                <span>{ride.transmission}</span>
              </div>
              
              <div className="flex items-start gap-2">
                <Badge variant="outline" className="mt-0.5">Urgency</Badge>
                <span>{ride.urgency}</span>
              </div>
            </div>
          </div>
        </div>
        
        <Separator className="my-6" />
        
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Trip Details</h3>
          
          <div className="space-y-4">
            <div className="flex flex-col space-y-1">
              <Label className="text-muted-foreground">Pickup Location</Label>
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                <span>{ride.pickup}</span>
              </div>
            </div>
            
            <div className="flex flex-col space-y-1">
              <Label className="text-muted-foreground">Dropoff Location</Label>
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                <span>{ride.dropoff}</span>
              </div>
            </div>
          </div>
        </div>
        
        {showCostField && (
          <>
            <Separator className="my-6" />
            <div className="space-y-2">
              <h3 className="text-lg font-semibold">Ride Cost</h3>
              <div className="flex items-end gap-2">
                <div className="flex-grow">
                  <Label htmlFor="cost">Cost Amount</Label>
                  <div className="flex items-center">
                    <span className="mr-2 text-lg">$</span>
                    <Input 
                      id="cost" 
                      type="number" 
                      placeholder="0.00" 
                      value={cost} 
                      onChange={(e) => setCost(e.target.value)}
                      className="flex-grow"
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>
                <Button onClick={handleSendCost}>Send Cost</Button>
              </div>
            </div>
          </>
        )}
        
        {ride.additionalNotes && (
          <>
            <Separator className="my-6" />
            <div className="space-y-2">
              <h3 className="text-lg font-semibold">Additional Notes</h3>
              <p className="text-muted-foreground">{ride.additionalNotes}</p>
            </div>
          </>
        )}
      </CardContent>
      
      <CardFooter className="border-t pt-4">
        <div className="flex justify-between items-center w-full gap-4">
          <p className="text-sm text-muted-foreground">
            {ride.assignedTo ? `Assigned to ${ride.assignedTo}` : 'Not assigned'}
          </p>
          
          <div className="flex items-center gap-4">
            <Label htmlFor="status" className="text-sm">Status:</Label>
            <Select 
              defaultValue={ride.status} 
              onValueChange={handleStatusChange}
              disabled={ride.status === 'new'}
            >
              <SelectTrigger id="status" className="w-[180px]">
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="assigned">Assigned</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
                <SelectItem value="no-show">No-Show</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardFooter>
    </Card>
  );
}
