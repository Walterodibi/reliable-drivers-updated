
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { useDispatch } from "@/context/DispatchContext";
import { useUser, } from "@/context/UserContext";
import type { User } from "@/context/UserContext"; // adjust path if needed
import { getRoleLabel } from "@/lib/config/roleLabels";
import { Ride, RideStatus, UrgencyLevel } from "@/types/ride";
import { CalendarDays, Clock, Mail, MapPin, Phone, User as UserIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/components/ui/use-toast";
import { useState, useEffect } from "react";
import Spinner from "./Spinner";

interface RideDetailsDialogProps {
  ride: Ride | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function RideDetailsDialog({ ride, open, onOpenChange }: RideDetailsDialogProps) {
  if (!ride) return null;

  const { updateStatus, updateRideCost, assignRideToUser } = useDispatch();
  const { isAdmin, currentUser, } = useUser();
  const { toast } = useToast();
  const [cost, setCost] = useState<string>("");
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [users, setUsers] = useState<User[]>([]);
  const [assignLoading, setAssignLoading] = useState(false);
  const [costLoading, setCostLoading] = useState(false);

  // if (!ride) return null;

  useEffect(() => {
    if (open && ride?.cost && cost === "") {
      setCost(ride.cost.toString());
    }
  }, [open, ride, cost]);
  
  const getUrgencyColor = (urgency: UrgencyLevel) => {
    switch (urgency) {
      case "low":
        return "bg-urgent-low";
      case "medium":
        return "bg-urgent-medium";
      case "high":
        return "bg-urgent-high";
      default:
        return "bg-urgent-low";
    }
  };

  const handleStatusChange = (value: string) => {
    updateStatus(ride.id, value as RideStatus);
  };

  const handleSendCost = async () => {
    const costValue = parseFloat(cost);
    if (isNaN(costValue) || costValue <= 0) {
      toast({ 
        variant: "destructive",
        title: "Invalid cost",
        description: "Please enter a valid cost value."
       });
      return;
    }
    setCostLoading(true);
    try {
      await updateRideCost(ride.id, costValue);
      toast({ title: "Cost updated", description: `Cost for ride ${ride.bookingId} has been updated.` });
    } finally {
      setCostLoading(false);
    }
  };
  
  const fetchUsers = async () => {
    try {
      const res = await fetch("https://pms.creatixtech.com/api/users");
      const data = await res.json();
      setUsers(data.users);
    } catch (error) {
      console.error("Failed to fetch users", error);
    }
  };

  const handleAssignRide = async () => {
    if (!selectedUserId) {
      toast({
        variant: "destructive",
        title: "No user selected",
        description: "Please select a user to assign this ride to."
      });
      return;
    }
    const selectedUser = users.find(user => user.id.toString() === selectedUserId);
    console.log(`SELECTEDUSER`, selectedUser)
    setAssignLoading(true);
    try {
      await fetch("https://pms.creatixtech.com/api/bookings/assign", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          booking_id: ride.bookingId,
          agent: selectedUser.firstName // or name/email if your API needs it
        }),
      });

      toast({
        title: "Ride assigned",
        description: `Ride ${ride.bookingId} has been assigned to the selected user.`
      });

    } catch (error) {
      toast({
        variant: "destructive",
        title: "Assignment failed",
        description: "Something went wrong. Please try again."
      });
    }
    setAssignLoading(false);
  };

  const canEditRide = () => {
    if (isAdmin()) return true;
    if (ride.status === "new") return false;
    if (["completed", "cancelled", "no-show"].includes(ride.status)) return false;
    return ride.assignedTo === currentUser.id;
  };

  const canChangeStatus = () => {
    if (isAdmin()) return true;
    if (["completed", "cancelled", "no-show"].includes(ride.status)) return false;
    return ride.assignedTo === currentUser.id || ride.assignedTo === currentUser.firstName;
  };

  // console.log(`USER IDS`, users.map(u => u.id));

  const showAssignOptions = isAdmin() && ride.status === "new";

  if (!isAdmin() && ride.status === "new") {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-md bg-card">
          <CardHeader className="px-0 pt-0">
            <CardTitle className="text-xl">Limited Access</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>Assign this ride to yourself to view full details.</p>
            <div className="flex justify-center">
              <Button 
                onClick={() => assignRideToUser(ride.id, currentUser.id)}
                className="w-full"
              >
                Assign to myself
              </Button>
            </div>
          </CardContent>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col bg-card">
        <CardHeader className="px-0 pt-0">
          <div className="flex justify-between items-center">
            <CardTitle className="text-xl">Booking #{ride.bookingId}</CardTitle>
            <Badge className={cn(getUrgencyColor(ride.urgency), "text-white")}>
              {ride.urgency.charAt(0).toUpperCase() + ride.urgency.slice(1)} Priority
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent className="flex-grow overflow-auto px-0">
          {showAssignOptions && (
            <div className="mb-6 p-4 border rounded-md bg-muted/30">
              <h3 className="text-lg font-semibold mb-3">Assign Ride</h3>
              <div className="flex items-end gap-2">
                <div className="flex-grow">
                  <Label htmlFor="assign-user">Assign to User</Label>
                  <Select 
                    value={selectedUserId} 
                    onValueChange={setSelectedUserId}
                    onOpenChange={(isOpen) => {
                      if (isOpen) {
                        fetchUsers(); // define this outside component
                      }
                    }}
                  >
                    <SelectTrigger id="assign-user">
                      <SelectValue placeholder="Select a user" />
                    </SelectTrigger>
                    <SelectContent>
                      {users.map(user => (
                        <SelectItem key={user.id} value={user.id.toString()}>
                          {user.firstName} ({getRoleLabel(user.userRole)})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleAssignRide} disabled={assignLoading}>
                {/* {assignLoading ? "⏳ Assigning..." : "Assign Ride"} */}
                {assignLoading ? <Spinner size="sm" className="mr-2" /> : "Assign Ride"}
                </Button>
              </div>
            </div>
          )}
          
          {/* customer information and ride details rows */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Customer Information</h3>
              
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <UserIcon className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium">{ride.name}</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <a href={`mailto:${ride.email}`} className="text-blue-600 hover:underline">
                    {ride.email}
                  </a>
                </div>
                
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <a href={`tel:${ride.phoneNumber}`} className="text-blue-600 hover:underline">
                    {ride.phoneNumber}
                  </a>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Ride Details</h3>
              
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <Badge variant="outline" className="mt-0.5">When</Badge>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-1">
                      <CalendarDays className="h-3 w-3" />
                      <span>{ride.date}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      <span>{ride.time}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-start gap-2">
                  <Badge variant="outline" className="mt-0.5">Transmission</Badge>
                  <span>{ride.transmission}</span>
                </div>
                
                <div className="flex items-start gap-2">
                  <Badge variant="outline" className="mt-0.5">Urgency</Badge>
                  <span>{ride.urgency}</span>
                </div>
              </div>
            </div>
          </div>
          
          <Separator className="my-6" />
          
          {/* Trip Details  */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Trip Details</h3>
            
            <div className="space-y-4">
              <div className="flex flex-col space-y-1">
                <Label className="text-muted-foreground">Pickup Location</Label>
                <div className="flex items-start gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <span>{ride.pickup}</span>
                </div>
              </div>
              
              <div className="flex flex-col space-y-1">
                <Label className="text-muted-foreground">Dropoff Location</Label>
                <div className="flex items-start gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <span>{ride.dropoff}</span>
                </div>
              </div>
            </div>
          </div>
          
          {ride.status === "pending" && canEditRide() && (
            <>
              <Separator className="my-6" />
              <div className="space-y-2">
                <h3 className="text-lg font-semibold">Ride Cost</h3>
                <div className="flex items-end gap-2">
                  <div className="flex-grow">
                    <Label htmlFor="cost">Cost Amount</Label>
                    <div className="flex items-center">
                      <span className="mr-2 text-lg">$</span>
                      <Input 
                        id="cost" 
                        type="number" 
                        placeholder="0.00" 
                        value={cost} 
                        onChange={(e) => setCost(e.target.value)}
                        className="flex-grow"
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </div>
                  <Button onClick={handleSendCost} disabled={costLoading}>
                  {costLoading ? <Spinner size="sm" className="mr-2" /> : "Send Cost"}
                  </Button>
                </div>
              </div>
            </>
          )}
          
          {/* Additional Notes Section */}
          {ride.additionalNotes && (
            <>
              <Separator className="my-6" />
              <div className="space-y-2">
                <h3 className="text-lg font-semibold">Additional Notes</h3>
                <p className="text-muted-foreground">{ride.additionalNotes}</p>
              </div>
            </>
          )}
        </CardContent>
        
        <CardFooter className="border-t pt-4 px-0">
          <div className="flex justify-between items-center w-full gap-4">
            <p className="text-sm text-muted-foreground">
              {ride.assignedTo ? `Assigned to ${ride.assignedTo}` : 'Not assigned'}
            </p>
            
            <div className="flex items-center gap-4">
              <Label htmlFor="status" className="text-sm">Status:</Label>
              <Select 
                defaultValue={ride.status} 
                onValueChange={handleStatusChange}
                disabled={!canChangeStatus()}
              >
                <SelectTrigger id="status" className="w-[180px]">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                  <SelectItem value="no-show">No-Show</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardFooter>
        
      </DialogContent> 
    </Dialog>
  );
}
