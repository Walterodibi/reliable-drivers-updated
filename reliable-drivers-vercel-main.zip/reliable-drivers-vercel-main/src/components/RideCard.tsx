
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { useDispatch } from "@/context/DispatchContext";
import { useUser } from "@/context/UserContext";
import { Ride, UrgencyLevel } from "@/types/ride";
import { Clock, MapPin } from "lucide-react";
import { cn } from "@/lib/utils";

interface RideCardProps {
  ride: Ride;
  onSelect: () => void;
  isSelected: boolean;
  showAssignButton?: boolean;
}

export function RideCard({ ride, onSelect, isSelected, showAssignButton = false }: RideCardProps) {
  const { assignRide } = useDispatch();
  const { isAdmin, currentUser } = useUser();

  const handleAssign = (e: React.MouseEvent) => {
    e.stopPropagation();
    assignRide(ride.id);
  };

  const getUrgencyColor = (urgency: string) => {
    const urgencyLower = urgency.toLowerCase();
    
    if (urgencyLower === 'high' || urgencyLower === 'asap') {
      return "bg-urgent-high";
    } else if (urgencyLower === 'medium') {
      return "bg-urgent-medium";
    } else {
      return "bg-urgent-low";
    }
  };

  const formatUrgency = (urgency: string) => {
    const urgencyLower = urgency.toLowerCase();
    
    if (urgencyLower === 'asap' || urgencyLower === 'high') {
      return 'ASAP';
    } else {
      return 'Scheduled';
    }
  };

  const isDisabled = !isAdmin() && ride.status === "new";

  return (
    <Card 
      className={cn(
        "transition-all hover:border-primary", 
        isSelected && "border-primary border-2",
        isDisabled ? "opacity-80 cursor-default" : "cursor-pointer"
      )} 
      onClick={isDisabled ? undefined : onSelect}
    >
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="font-semibold text-lg">{ride.name}</h3>
            <p className="text-sm text-muted-foreground">Booking #{ride.bookingId}</p>
          </div>
          <Badge className={cn(getUrgencyColor(ride.urgency), "text-white")}>
            {formatUrgency(ride.urgency)}
          </Badge>
        </div>
        
        <div className="space-y-2 mt-4">
          <div className="flex items-center gap-2 text-sm">
            <Clock className="h-4 w-4" />
            <span>{ride.timestamp}</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm">
            <MapPin className="h-4 w-4" />
            <span className="truncate">{ride.pickup}</span>
          </div>
        </div>
      </CardContent>
      
      {showAssignButton && !isAdmin() && (
        <CardFooter className="p-2 pt-0">
          <Button onClick={handleAssign} className="w-full">
            Assign to me
          </Button>
        </CardFooter>
      )}
      
      {showAssignButton && isAdmin() && (
        <CardFooter className="p-2 pt-0">
          <Button onClick={onSelect} className="w-full">
            Assign ride
          </Button>
        </CardFooter>
      )}
    </Card>
  );
}
