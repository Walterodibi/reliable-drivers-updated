
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { Switch } from "@/components/ui/switch";
import { useUser } from "@/context/UserContext";
import { Users } from "lucide-react";
import { UserManagementDialog } from "./UserManagementDialog";

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SettingsDialog({ open, onOpenChange }: SettingsDialogProps) {
  const { toast } = useToast();
  const { isAdmin, isDarkMode, toggleDarkMode } = useUser();
  const [isUserManagementOpen, setIsUserManagementOpen] = useState(false);
  
  const handleSave = () => {
    toast({
      title: "Settings Saved",
      description: "Settings have been updated."
    });
    
    onOpenChange(false);
  };
  
  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Settings</DialogTitle>
            <DialogDescription>
              Configure your application preferences
            </DialogDescription>
          </DialogHeader>
          
          <Tabs defaultValue="general" className="mt-2">
            <TabsList className="grid w-full grid-cols-1">
              <TabsTrigger value="general">General</TabsTrigger>
            </TabsList>
            
            <TabsContent value="general" className="space-y-4 py-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="dark-mode" className="text-base">Dark Mode</Label>
                  <div className="text-sm text-muted-foreground">
                    Switch between light and dark themes
                  </div>
                </div>
                <Switch 
                  id="dark-mode" 
                  checked={isDarkMode}
                  onCheckedChange={toggleDarkMode}
                />
              </div>
              
              {isAdmin() && (
                <div className="pt-6">
                  <Button 
                    variant="outline" 
                    className="w-full" 
                    onClick={() => setIsUserManagementOpen(true)}
                  >
                    <Users className="mr-2 h-4 w-4" />
                    Manage Users
                  </Button>
                </div>
              )}
            </TabsContent>
          </Tabs>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <UserManagementDialog 
        open={isUserManagementOpen}
        onOpenChange={setIsUserManagementOpen}
      />
    </>
  );
}
