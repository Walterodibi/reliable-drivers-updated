
// import { Button } from "@/components/ui/button";
// import {
//   DropdownMenu,
//   DropdownMenuContent,
//   DropdownMenuItem,
//   DropdownMenuTrigger,
// } from "@/components/ui/dropdown-menu";
// import { useUser, UserRole } from "@/context/UserContext";
// import { ChevronDown, ShieldCheck, User } from "lucide-react";

// export function RoleSelector() {
//   const { currentUser, setUser, isAdmin } = useUser();

//   const switchToRole = (role: UserRole) => {
//     setUser({
//       ...currentUser,
//       userRole: role
//     });
//   };

//   return (
//     <DropdownMenu>
//       <DropdownMenuTrigger asChild>
//         <Button variant="outline" className="ml-auto">
//           {currentUser.userRole === "admin" ? (
//             <ShieldCheck className="mr-2 h-4 w-4" />
//           ) : (
//             <User className="mr-2 h-4 w-4" />
//           )}
//           {currentUser.userRole.charAt(0).toUpperCase() + currentUser.userRole.slice(1)}
//           {isAdmin() && <ChevronDown className="ml-2 h-4 w-4" />}
//         </Button>
//       </DropdownMenuTrigger>
//       {isAdmin() && (
//         <DropdownMenuContent align="end">
//           <DropdownMenuItem onClick={() => switchToRole("admin")}>
//             <ShieldCheck className="mr-2 h-4 w-4" />
//             <span>Admin</span>
//           </DropdownMenuItem>
//           <DropdownMenuItem onClick={() => switchToRole("standard")}>
//             <User className="mr-2 h-4 w-4" />
//             <span>Standard</span>
//           </DropdownMenuItem>
//         </DropdownMenuContent>
//       )}
//     </DropdownMenu>
//   );
// }


import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useUser, UserRole } from "@/context/UserContext";
import { ChevronDown, ShieldCheck, User } from "lucide-react";
import { getRoleLabel } from "@/lib/config/roleLabels";

export function RoleSelector() {
  const { currentUser, setUser, isAdmin } = useUser();
  console.log("userRole:", currentUser.userRole);
  console.log("isAdmin:", isAdmin());
  
  // ✅ Map backend role values to labels
  // const getRoleLabel = (role: string | undefined) => {
  //   if (role === "1") return "Admin";
  //   if (role === "2") return "Standard";
  //   return "Unknown";
  // };

  // ✅ Set role (as string like "1" or "2")
  const switchToRole = (role: "1" | "2") => {
    setUser({
      ...currentUser,
      userRole: role
    });
  };

  if (!currentUser?.userRole) return null;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="ml-auto">
          {currentUser.userRole === "1" ? (
            <ShieldCheck className="mr-2 h-4 w-4" />
          ) : (
            <User className="mr-2 h-4 w-4" />
          )}
          {getRoleLabel(currentUser.userRole)}
          {isAdmin() && <ChevronDown className="ml-2 h-4 w-4" />}
        </Button>
      </DropdownMenuTrigger>
      {isAdmin() && (
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => switchToRole("1")}>
            <ShieldCheck className="mr-2 h-4 w-4" />
            <span>Admin</span>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => switchToRole("2")}>
            <User className="mr-2 h-4 w-4" />
            <span>Standard</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      )}
    </DropdownMenu>
  );
}
