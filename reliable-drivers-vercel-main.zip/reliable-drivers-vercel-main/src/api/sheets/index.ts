
// This file now uses the Excel file data for the app

import type { Ride, RideStatus } from '@/types/ride';
import { 
  readExcelFile, 
  saveRideData, 
  updateRide, 
  getAllRides, 
  findRideById 
} from '@/lib/excelReader';

// API interface that now uses Excel data
export const sheetsApi = {
  // Fetch all rides
  fetchRides: async (): Promise<Ride[]> => {
    try {
      console.log("Fetching rides from Excel file...");
      const data = await readExcelFile();
      
      // Save to in-memory storage for later use
      saveRideData(data);
      
      console.log("Fetched rides data:", data);
      return data;
    } catch (error) {
      console.error('Error fetching rides:', error);
      throw error;
    }
  },

  // Fetch only unassigned rides
  fetchUnassignedRides: async (): Promise<Ride[]> => {
    try {
      const allRides = await readExcelFile();
      const unassignedRides = allRides.filter(ride => 
        ride.status === "new" || ride.assignmentStatus === "unassigned"
      );
      return unassignedRides;
    } catch (error) {
      console.error('Error fetching unassigned rides:', error);
      throw error;
    }
  },

  // Assign ride to user
  assignRideToUser: async (rideId: string, userId: string): Promise<Ride> => {
    try {
      const ride = findRideById(rideId);
      
      if (!ride) {
        throw new Error(`Ride with ID ${rideId} not found`);
      }
      
      const updatedRide: Ride = {
        ...ride,
        assignedTo: userId,
        assignmentStatus: "assigned",
        assignedAt: new Date().toISOString(),
        status: "pending"
      };
      
      return updateRide(updatedRide);
    } catch (error) {
      console.error('Error assigning ride:', error);
      throw error;
    }
  },

  // Update ride status
  updateRideStatus: async (rideId: string, status: RideStatus): Promise<Ride> => {
    try {
      const ride = findRideById(rideId);
      
      if (!ride) {
        throw new Error(`Ride with ID ${rideId} not found`);
      }
      
      const updatedRide: Ride = {
        ...ride,
        status: status,
        completedAt: ["completed", "cancelled", "no-show"].includes(status) 
          ? new Date().toISOString() 
          : ride.completedAt
      };
      
      return updateRide(updatedRide);
    } catch (error) {
      console.error('Error updating ride status:', error);
      throw error;
    }
  },

  // Update ride cost
  updateRideCost: async (rideId: string, cost: number): Promise<Ride> => {
    try {
      const ride = findRideById(rideId);
      
      if (!ride) {
        throw new Error(`Ride with ID ${rideId} not found`);
      }
      
      const updatedRide: Ride = {
        ...ride,
        cost: cost
      };
      
      return updateRide(updatedRide);
    } catch (error) {
      console.error('Error updating ride cost:', error);
      throw error;
    }
  },

  // Test connection
  testConnection: async () => {
    try {
      console.log("Testing Excel file connection...");
      const data = await readExcelFile();
      const success = data.length > 0;
      
      return {
        success,
        readSuccess: success,
        writeSuccess: true,
        message: success 
          ? `Successfully loaded ${data.length} rides from Excel file` 
          : "Failed to load data from Excel file"
      };
    } catch (error) {
      console.error('Error testing connection:', error);
      return {
        success: false,
        readSuccess: false,
        writeSuccess: false,
        message: `Failed to connect to Excel file: ${error instanceof Error ? error.message : String(error)}`
      };
    }
  },

  // For compatibility with the existing API
  deleteTestSheet: async (sheetName?: string) => {
    return { success: true, message: "Not applicable in browser mode" };
  }
};
