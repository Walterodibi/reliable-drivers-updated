
import { 
  createContext, 
  useContext, 
  useState, 
  useEffect, 
  ReactNode,
  useMemo,
  useRef
} from "react";
import { Ride, RideStatus } from "@/types/ride";
import { sheetsApi } from "@/api/sheets";
import { useToast } from "@/components/ui/use-toast";
import { useUser } from "@/context/UserContext";
import { mockRides } from "@/lib/mockData";

type DispatchContextType = {
  rides: Ride[];
  loading: boolean;
  error: string | null;
  selectedRideId: string | null;
  setSelectedRideId: (id: string | null) => void;
  assignRide: (rideId: string) => Promise<void>;
  assignRideToUser: (rideId: string, userId: string) => Promise<void>;
  updateStatus: (rideId: string, status: RideStatus) => Promise<void>;
  updateRideCost: (rideId: string, cost: number) => Promise<void>;
  refreshRides: () => Promise<void>;
  newRides: Ride[];
  myAssignedRides: Ride[];
  allAssignedRides: Ride[];
  completedRides: Ride[];
  autoRefreshEnabled: boolean;
  toggleAutoRefresh: () => void;
  useMockData: boolean;
  toggleUseMockData: () => void;
};

const DispatchContext = createContext<DispatchContextType | null>(null);

export function DispatchProvider({ children }: { children: ReactNode }) {
  const { currentUser, isAdmin } = useUser();
  const [rides, setRides] = useState<Ride[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedRideId, setSelectedRideId] = useState<string | null>(null);
  const [autoRefreshEnabled, setAutoRefreshEnabled] = useState<boolean>(true);
  const [useMockData, setUseMockData] = useState<boolean>(false); // Default to using mock data
  const autoRefreshIntervalRef = useRef<number | null>(null);
  
  const { toast } = useToast();

  // const refreshRides = async () => {
  //   try {
  //     setLoading(true);
      
  //     if (useMockData) {
  //       console.log("Using mock data...");
  //       setRides(mockRides);
  //       setError(null);
  //       setLoading(false);
  //       return;
  //     }
      
  //     console.log("Refreshing rides from API...");
  //     const fetchedRides = await sheetsApi.fetchRides();
  //     console.log("Fetched rides from API:", fetchedRides);
  //     setRides(fetchedRides);
  //     setError(null);
      
  //     // Only show toast if rides were successfully fetched and this is the first successful fetch
  //     if (fetchedRides.length > 0 && rides.length === 0) {
  //       const firstEntry = fetchedRides[0];
  //       const firstEntryDetails = `First booking: #${firstEntry.bookingId}
  //       Customer: ${firstEntry.name}
  //       From: ${firstEntry.pickup}
  //       To: ${firstEntry.dropoff}
  //       Date: ${firstEntry.date}
  //       Time: ${firstEntry.time}`;
        
  //       toast({
  //         title: "Sheet Connection Test",
  //         description: firstEntryDetails,
  //         duration: 10000, // Show for 10 seconds to give time to read
  //       });
        
  //       toast({
  //         title: "Success",
  //         description: "Connected to booking sheet and loaded data"
  //       });
  //     }
  //   } catch (err) {
  //     console.error("Failed to fetch rides from API:", err);
  //     setError("Failed to connect to booking sheet. Make sure the backend server is running at http://localhost:3001");
  //     toast({
  //       variant: "destructive",
  //       title: "Connection Error",
  //       description: "Failed to load data from the booking sheet. Are you running the backend server with 'node server.js'?"
  //     });
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  const refreshRides = async () => {
    try {
      setLoading(true);
  
      const [completedRes, newRes, pendingRes] = await Promise.all([
        fetch("https://pms.creatixtech.com/api/completed"),
        fetch("https://pms.creatixtech.com/api/bookings/new"),
        fetch("https://pms.creatixtech.com/api/bookings/pending")
      ]);
  
      if (!completedRes.ok || !newRes.ok || !pendingRes.ok) throw new Error("API fetch failed");
  
      const [completedData, newData, pendingData] = await Promise.all([
        completedRes.json(),
        newRes.json(),
        pendingRes.json()
      ]);
  
      const normalize = (ride: any) => ({
        id: ride.bookingId || "",
        name: ride.name || "",
        email: ride.email || "",
        phoneNumber: ride.phoneNumber || "",
        bookingId: ride.bookingId || "",
        pickup: ride.pickup || "",
        dropoff: ride.dropoff || "",
        transmission: ride.transmission || "",
        urgency: ride.urgency?.toLowerCase() || "",
        // additionalNotes: ride["Additional notes"],
        additionalNotes: ride.additionalNotes || "",
        // status: ride.status?.toLowerCase() || "",
        status: (ride.status?.toLowerCase() || "new") as RideStatus,
        assignedTo: ride.agent || ride.driver || "",
        assignmentStatus: ride.assignmentStatus?.toLowerCase() || "",
        cost: ride.cost || "",
        completedAt: ride.timestamp || "",
        time: ride.time || "",
        date: ride.date || "",
        serviceType: ride.serviceType || "",
        timestamp: ride.timestamp || "",
        agent: ride.agent || "",
        driver: ride.driver || "",
      });
      //const uniqueNewData = newData.data.map(normalize) needs to be removed and recorrection required from backend.
      const completed = completedData.data.map(normalize);
      // const newDataa = newData.data.map(normalize);
      const uniqueNewData = Array.from(new Map(newData.data.map(ride => [ride.bookingId, ride])).values());
      const newDataa = uniqueNewData.map(normalize);
      const pendingDataa = pendingData.data.map(normalize);
      const allRides = [...newDataa, ...pendingDataa, ...completed];
      console.log("Pending normalized:", pendingDataa);
      
  
      const removeDuplicates = (rides: typeof allRides) => {
        const map = new Map();
        rides.forEach(ride => map.set(ride.id, ride));
        return Array.from(map.values());
      };
      
      setRides(removeDuplicates(allRides));
      setError(null);
    } catch (err) {
      console.error("Failed to fetch rides:", err);
      setError("Failed to connect to booking API.");
      toast({
        variant: "destructive",
        title: "Connection Error",
        description: "Failed to load data from the booking API."
      });
    } finally {
      setLoading(false);
    }
  };
  
  // Toggle between real and mock data
  // const toggleUseMockData = () => {
  //   setUseMockData(prev => !prev);
  //   toast({
  //     title: useMockData ? "Using Real Data" : "Using Mock Data",
  //     description: useMockData ? 
  //       "Switched to real data from the booking sheet" : 
  //       "Switched to mock data for development"
  //   });
  //   refreshRides();
  // };

  const toggleUseMockData = () => {
    setUseMockData((prev) => {
      const newState = !prev;
 
      toast({
        title: newState ? "Mock Mode Enabled" : "Live API Mode Enabled",
        description: newState
          ? "Now using mock rides for testing."
          : "Now using real booking data from the API.",
      });
 
      // Fetch updated data based on new mode
      setTimeout(refreshRides, 200); // Small delay ensures state updates before fetch
      return newState;
    });
  };

  // Setup auto-refresh
  useEffect(() => {
    // Clear existing interval when component unmounts or autoRefresh state changes
    if (autoRefreshIntervalRef.current) {
      clearInterval(autoRefreshIntervalRef.current);
      autoRefreshIntervalRef.current = null;
    }
    
    // Set up new interval if autoRefresh is enabled
    if (autoRefreshEnabled) {
      // TypeScript expects a number for setInterval, but it returns number in browser and NodeJS.Timer in Node
      autoRefreshIntervalRef.current = window.setInterval(() => {
        console.log("Auto-refreshing rides data...");
        refreshRides();
      }, 10000) as unknown as number;
    }
    
    // Cleanup on unmount
    return () => {
      if (autoRefreshIntervalRef.current) {
        clearInterval(autoRefreshIntervalRef.current);
      }
    };
  }, [autoRefreshEnabled, useMockData]);

  // Initial data fetch
  useEffect(() => {
    refreshRides();
  }, []);

  const toggleAutoRefresh = () => {
    setAutoRefreshEnabled(prevState => !prevState);
    toast({
      title: autoRefreshEnabled ? "Auto-refresh disabled" : "Auto-refresh enabled",
      description: autoRefreshEnabled ? 
        "Booking data will no longer refresh automatically" : 
        "Booking data will refresh every 10 seconds"
    });
  };

  const assignRide = async (rideId: string) => {
  try {
    const ride = rides.find(r => r.id === rideId);
    if (!ride) throw new Error("Ride not found");

    const res = await fetch("https://pms.creatixtech.com/api/bookings/assign", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        booking_id: ride.bookingId,
        agent: currentUser.firstName, // or currentUser.id if API expects
      }),
    });

    if (!res.ok) throw new Error("Failed to assign ride");

    toast({
      title: "Ride Assigned",
      description: `You have been assigned ride ${ride.bookingId}.`,
    });

    refreshRides(); // to update UI

  } catch (err) {
    console.error("Failed to assign ride:", err);
    toast({
      variant: "destructive",
      title: "Error",
      description: "Failed to assign ride. Please try again.",
    });
  }
};

  const assignRideToUser = async (rideId: string, userId: string) => {
    try {
      if (!isAdmin()) {
        throw new Error("Only admins can assign rides to other users");
      }
      
      // if (useMockData) {
      //   // Handle assignment with mock data
      //   const updatedRide = { 
      //     ...rides.find(r => r.id === rideId)!,
      //     status: "pending" as RideStatus,
      //     assignedTo: userId,
      //     assignmentStatus: "assigned",
      //     assignedAt: new Date().toISOString()
      //   };
        
      //   setRides(prev => prev.map(ride => 
      //     ride.id === rideId ? updatedRide : ride
      //   ));
        
      //   toast({
      //     title: "Ride Assigned (Mock)",
      //     description: `Ride ${updatedRide.bookingId} has been assigned.`
      //   });
        
      //   return;
      // }
      
      const updatedRide = await sheetsApi.assignRideToUser(rideId, userId);
      setRides(prev => prev.map(ride => 
        ride.id === rideId ? updatedRide : ride
      ));
      toast({
        title: "Ride Assigned",
        description: `Ride ${updatedRide.bookingId} has been assigned.`
      });
    } catch (err) {
      console.error("Failed to assign ride:", err);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to assign ride. Please try again."
      });
      throw err;
    }
  };

  const updateStatus = async (rideId: string, status: RideStatus) => {
    try {
      const ride = rides.find(r => r.id === rideId);
      if (!ride) throw new Error("Ride not found");
 
      if (!isAdmin() &&
          ["completed", "cancelled", "no-show"].includes(ride.status) &&
          ride.assignedTo !== currentUser.id) {
        throw new Error("You don't have permission to change the status of this ride");
      }
 
      // if (useMockData) {
      //   // mock handling
      //   const now = new Date().toISOString();
      //   const updatedRide = {
      //     ...ride,
      //     status,
      //     assignmentStatus: status,
      //     completedAt: ["completed", "cancelled", "no-show"].includes(status) ? now : ride.completedAt
      //   };
      //   setRides(prev => prev.map(ride => ride.id === rideId ? updatedRide : ride));
      //   toast({ title: "Status Updated (Mock)", description: `Ride ${updatedRide.bookingId} marked as ${status}.` });
      //   return;
      // }
 
      // 🔥 Real-time API call inline here
      const response = await fetch("https://pms.creatixtech.com/api/bookings/update", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
          // Add Authorization if needed
        },
        body: JSON.stringify({
          booking_id: ride.bookingId,
          Status: status
        })
      });
 
      if (!response.ok) {
        throw new Error("Failed to update booking status");
      }
 
      // Optionally handle API response
      const data = await response.json();
 
      // Update local state
      const updatedRide = {
        ...ride,
        status,
        assignmentStatus: status,
        completedAt: ["completed", "cancelled", "no-show"].includes(status)
          ? new Date().toISOString()
          : ride.completedAt
      };
 
      setRides(prev => prev.map(ride => ride.id === rideId ? updatedRide : ride));
 
      toast({
        title: "Status Updated",
        description: `Ride ${updatedRide.bookingId} marked as ${status}.`
      });
 
    } catch (err) {
      console.error("Failed to update ride status:", err);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update status. Please try again."
      });
    }
  };
  
  // const updateRideCost = async (rideId: string, cost: number) => {
  //   try {
  //     if (useMockData) {
  //       // Handle cost update with mock data
  //       const updatedRide = { 
  //         ...rides.find(r => r.id === rideId)!,
  //         cost
  //       };
        
  //       setRides(prev => prev.map(ride => 
  //         ride.id === rideId ? updatedRide : ride
  //       ));
        
  //       toast({
  //         title: "Cost Updated (Mock)",
  //         description: `Cost for ride ${updatedRide.bookingId} has been set to $${cost}.`
  //       });
        
  //       return;
  //     }
      
  //     const updatedRide = await sheetsApi.updateRideCost(rideId, cost);
      
  //     setRides(prev => prev.map(ride => 
  //       ride.id === rideId ? updatedRide : ride
  //     ));
      
  //     toast({
  //       title: "Cost Updated",
  //       description: `Cost for ride ${updatedRide.bookingId} has been set to $${cost}.`
  //     });
  //   } catch (err) {
  //     console.error("Failed to update ride cost:", err);
  //     toast({
  //       variant: "destructive",
  //       title: "Error",
  //       description: "Failed to update cost. Please try again."
  //     });
  //   }
  // };

  const updateRideCost = async (rideId: string, cost: number) => {
    
    try {
      const rideToUpdate = rides.find(r => r.id === rideId);
      if (!rideToUpdate) throw new Error("Ride not found");
 
      const response = await fetch("https://pms.creatixtech.com/api/bookings/send-cost", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
          // Add this if authentication is needed:
          // "Authorization": `Bearer ${yourToken}`
        },
        body: JSON.stringify({
          booking_id: rideToUpdate.bookingId, // required by the API
          cost: cost.toString()
        })
      });
 
      if (!response.ok) {
        throw new Error("Failed to send cost to server");
      }
 
      const result = await response.json(); // optionally use this if response data is needed
 
      // Update state with new cost
      const updatedRide = {
        ...rideToUpdate,
        cost
      };
 
      setRides(prev => prev.map(ride =>
        ride.id === rideId ? updatedRide : ride
      ));
 
      toast({
        title: "Cost Updated",
        description: `Cost for ride ${updatedRide.bookingId} has been set to $${cost}.`
      });
 
    } catch (err) {
      console.error("Failed to update ride cost:", err);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update cost. Please try again."
      });
    }
  };

  // Use our modified data filtering for newRides
  const newRides = useMemo(() => 
    rides.filter(ride => 
      ride.status?.toLowerCase() === "" || ride.assignmentStatus?.toLowerCase() === "unassigned"
    ),
    [rides]
  );
  
  // const myAssignedRides = useMemo(() => 
  //   rides.filter(ride => 
  //     ride.status === "pending" && 
  //     ride.assignedTo === currentUser.firstName && 
  //     ride.assignmentStatus !== "unassigned"
  //   ),
  //   [rides, currentUser.id]
  // );

  const myAssignedRides = useMemo(() => {
    return rides.filter(ride => {
      // console.log("AssignedTo:", ride.assignedTo, "CurrentUser:", currentUser.id);
      return (
        ride.status === "pending" &&
        ride.assignedTo === currentUser.firstName &&
        ride.assignmentStatus !== "unassigned"
      );
    });
  }, [rides, currentUser.id]);
  
  const allAssignedRides = useMemo(() => 
    rides.filter(ride => 
      (ride.status as string).toLowerCase() === "pending" && 
      // ride.assignmentStatus === "Assigned"
      ride.assignmentStatus?.toLowerCase() === "assigned"
    ),
    [rides]
  );

  const completedRides = useMemo(() => 
    rides.filter(ride => 
      ["completed", "cancelled", "no-show"].includes(ride.status)
    ),
    [rides]
  );

  const value = {
    rides,
    loading,
    error,
    selectedRideId,
    setSelectedRideId,
    assignRide,
    assignRideToUser,
    updateStatus,
    updateRideCost,
    refreshRides,
    newRides,
    myAssignedRides,
    allAssignedRides,
    completedRides,
    autoRefreshEnabled,
    toggleAutoRefresh,
    useMockData,
    toggleUseMockData
  };

  useEffect(() => {
    console.log("All rides updated:", rides);
  }, [rides]);

  return (
    <DispatchContext.Provider value={value}>
      {children}
    </DispatchContext.Provider>
  );
}

export function useDispatch() {
  const context = useContext(DispatchContext);
  if (!context) {
    throw new Error("useDispatch must be used within a DispatchProvider");
  }
  return context;
}
