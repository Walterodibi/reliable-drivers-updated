
// import { createContext, useContext, ReactNode, useState, useEffect } from "react";
// import { useToast } from "@/components/ui/use-toast";

// export type UserRole = "admin" | "standard";

// interface User {
//   id: string;
//   name: string;
//   role: UserRole;
//   email?: string;
//   username?: string;
// }

// interface UserContextType {
//   currentUser: User;
//   setUser: (user: User) => void;
//   isAdmin: () => boolean;
//   isDarkMode: boolean;
//   toggleDarkMode: () => void;
//   users: User[];
//   addUser: (user: Omit<User, "id">) => void;
//   removeUser: (userId: string) => void;
//   isUsernameTaken: (username: string) => boolean;
// }

// const USERS_STORAGE_KEY = "dispatcher_users";
// const CURRENT_USER_KEY = "dispatcher_current_user";
// const THEME_PREFERENCE_KEY = "dispatcher_theme";

// const UserContext = createContext<UserContextType | null>(null);

// export const UserProvider = ({ children }: { children: ReactNode }) => {
//   const { toast } = useToast();
  
  
//   // Load existing users or create default admin
//   // const initializeUsers = (): User[] => {
//   //   const storedUsers = localStorage.getItem(USERS_STORAGE_KEY);
//   //   if (storedUsers) {
//   //     return JSON.parse(storedUsers);
//   //   }
    
//   //   // Initial user list with admin
//   //   const initialUsers: User[] = [
//   //     {
//   //       id: "user-1",
//   //       name: "Admin User",
//   //       role: "admin" as UserRole,
//   //       email: "admin@example.com",
//   //       username: "admin"
//   //     },
//   //     {
//   //       id: "user-2",
//   //       name: "Standard User",
//   //       role: "standard" as UserRole,
//   //       email: "user@example.com",
//   //       username: "user"
//   //     }
//   //   ];
    
//   //   localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(initialUsers));
//   //   return initialUsers;
//   // };
  
//   // Initialize users
//   const [users, setUsers] = useState<User[]>([]);

//   useEffect(() => {
//     const fetchUsers = async () => {
//       try {
//         const res = await fetch("https://pms.creatixtech.com/api/users", {
//           headers: {
//             Authorization: `Bearer ${localStorage.getItem("token")}`
//           }

//         });
//         const data = await res.json();
//         setUsers(data);``
//       } catch (error) {
//         console.error("Failed to fetch users", error);
//       }
//     };
  
//     fetchUsers();
//   }, []);
  
//   console.log("TOKEN", localStorage.getItem("token"));
  
  
//   // Load current user or use default admin
//   const initializeCurrentUser = (): User => {
//     const storedUser = localStorage.getItem(CURRENT_USER_KEY);
//     if (storedUser) {
//       return JSON.parse(storedUser);
//     }
    
//     // Default to first user (admin)
//     return users[0];
//   };

//   // Initialize theme preference
//   const initializeTheme = (): boolean => {
//     const storedTheme = localStorage.getItem(THEME_PREFERENCE_KEY);
//     if (storedTheme) {
//       return storedTheme === "dark";
//     }
//     return window.matchMedia("(prefers-color-scheme: dark)").matches;
//   };
  
//   // const [currentUser, setCurrentUser] = useState<User>(initializeCurrentUser);
//   const [currentUser, setCurrentUser] = useState<User | null>(null);

//   const [isDarkMode, setIsDarkMode] = useState<boolean>(initializeTheme);
//   if (!currentUser) return null;

//   useEffect(() => {
//     if (!currentUser && users.length > 0) {
//       setCurrentUser(users[0]);
//     }
//   }, [users]);
  
  
//   // Apply dark mode theme
//   useEffect(() => {
//     if (isDarkMode) {
//       document.documentElement.classList.add("dark");
//     } else {
//       document.documentElement.classList.remove("dark");
//     }
//     localStorage.setItem(THEME_PREFERENCE_KEY, isDarkMode ? "dark" : "light");
//   }, [isDarkMode]);
  
//   // Save current user to localStorage whenever it changes
//   useEffect(() => {
//     localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(currentUser));
//   }, [currentUser]);
  
//   // Save users to localStorage whenever they change
//   // useEffect(() => {
//   //   localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
//   // }, [users]);

//   const setUser = (user: User) => {
//     setCurrentUser(user);
//   };

//   const isAdmin = () => currentUser.role === "admin";
  
//   const toggleDarkMode = () => {
//     setIsDarkMode(!isDarkMode);
//   };
  
//   // Check if username is already taken (case insensitive)
//   const isUsernameTaken = (username: string): boolean => {
//     return users.some(user => 
//       user.username?.toLowerCase() === username.toLowerCase()
//     );
//   };
  
//   // User management (admin only)
//   const addUser = (userData: Omit<User, "id">) => {
//     if (!isAdmin() && users.length > 0) {
//       toast({
//         variant: "destructive",
//         title: "Access Denied",
//         description: "Only administrators can add users"
//       });
//       return;
//     }
    
//     // Check if username is already taken
//     if (userData.username && isUsernameTaken(userData.username)) {
//       toast({
//         variant: "destructive",
//         title: "Username Unavailable",
//         description: "This username is already taken. Please choose another one."
//       });
//       throw new Error("Username already taken");
//     }
    
//     const newUser: User = {
//       ...userData,
//       id: `user-${users.length + 1}`
//     };
    
//     setUsers(prev => [...prev, newUser]);
    
//     toast({
//       title: "User Added",
//       description: `${newUser.name} has been added as a ${newUser.role} user`
//     });
//   };
  
//   const removeUser = (userId: string) => {
//     if (!isAdmin()) {
//       toast({
//         variant: "destructive",
//         title: "Access Denied",
//         description: "Only administrators can remove users"
//       });
//       return;
//     }
    
//     // Never allow removing the current user or the last admin
//     if (userId === currentUser.id) {
//       toast({
//         variant: "destructive",
//         title: "Action Denied",
//         description: "You cannot remove yourself"
//       });
//       return;
//     }
    
//     const userToRemove = users.find(u => u.id === userId);
//     if (!userToRemove) return;
    
//     // Check if this is the last admin
//     if (userToRemove.role === "admin" && users.filter(u => u.role === "admin").length <= 1) {
//       toast({
//         variant: "destructive",
//         title: "Action Denied",
//         description: "Cannot remove the last administrator"
//       });
//       return;
//     }
    
//     setUsers(prev => prev.filter(u => u.id !== userId));
    
//     toast({
//       title: "User Removed",
//       description: `${userToRemove.name} has been removed`
//     });
//   };

//   return (
//     <UserContext.Provider value={{ 
//       currentUser, 
//       setUser, 
//       isAdmin, 
//       isDarkMode, 
//       toggleDarkMode,
//       users,
//       addUser,
//       removeUser,
//       isUsernameTaken
//     }}>
//       {children}
//     </UserContext.Provider>
//   );
// };

// export const useUser = () => {
//   const context = useContext(UserContext);
//   if (!context) {
//     throw new Error("useUser must be used within a UserProvider");
//   }
//   return context;
// };


import { createContext, useContext, ReactNode, useState, useEffect } from "react";
import { useToast } from "@/components/ui/use-toast";

export type UserRole = "admin" | "standard";

export interface User {
  id: string;
  firstName: string;
  userRole: string;
  email?: string;
  // username?: string;
  lastName?: string;
  phone?: string;
}

interface UserContextType {
  currentUser: User;
  setUser: (user: User) => void;
  isAdmin: () => boolean;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  users: User[];
  addUser: (user: Omit<User, "id">) => void;
  removeUser: (userId: string) => void;
  isAuthenticated: () => boolean;
  // isUsernameTaken: (username: string) => boolean;
}

const USERS_STORAGE_KEY = "dispatcher_users";
const CURRENT_USER_KEY = "dispatcher_current_user";
const THEME_PREFERENCE_KEY = "dispatcher_theme";

const UserContext = createContext<UserContextType | null>(null);

export const UserProvider = ({ children }: { children: ReactNode }) => {
  const { toast } = useToast();
  
  // Load existing users or create default admin
  // const initializeUsers = (): User[] => {
  //   const storedUsers = localStorage.getItem(USERS_STORAGE_KEY);
  //   if (storedUsers) {
  //     return JSON.parse(storedUsers);
  //   }
    
  //   // Initial user list with admin
  //   const initialUsers: User[] = [
  //     {
  //       id: "user-1",
  //       firstName: "Admin User",
  //       userRole: "admin" as UserRole,
  //       email: "admin@example.com",
  //       // username: "admin"
  //     },
  //     {
  //       id: "user-2",
  //       firstName: "Standard User",
  //       userRole: "standard" as UserRole,
  //       email: "user@example.com",
  //       // username: "user"
  //     }
  //   ];
    
  //   localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(initialUsers));
  //   return initialUsers;
  // };

  const initializeUsers = (): User[] => {
    const storedUsers = localStorage.getItem(USERS_STORAGE_KEY);
    return storedUsers ? JSON.parse(storedUsers) : [];
  };
  
  
  // Initialize users
  const [users, setUsers] = useState<User[]>(initializeUsers);
  
  // Load current user or use default admin
  // const initializeCurrentUser = (): User => {
  //   const storedUser = localStorage.getItem(CURRENT_USER_KEY);
  //   if (storedUser) {
  //     return JSON.parse(storedUser);
  //   }
    
  //   // Default to first user (admin)
  //   return users[0];
  // };

  const initializeCurrentUser = (): User => {
    const storedUser = localStorage.getItem(CURRENT_USER_KEY);
    if (storedUser) {
      return JSON.parse(storedUser);
    }
  
    // If no user is stored, return an empty object (unauthenticated)
    return { id: "", firstName: "", userRole: "" };
  };
  

  // Initialize theme preference
  const initializeTheme = (): boolean => {
    const storedTheme = localStorage.getItem(THEME_PREFERENCE_KEY);
    if (storedTheme) {
      return storedTheme === "dark";
    }
    return window.matchMedia("(prefers-color-scheme: dark)").matches;
  };
  
  const [currentUser, setCurrentUser] = useState<User>(initializeCurrentUser);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(initializeTheme);
  
  // Apply dark mode theme
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
    localStorage.setItem(THEME_PREFERENCE_KEY, isDarkMode ? "dark" : "light");
  }, [isDarkMode]);
  
  // Save current user to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(currentUser));
  }, [currentUser]);
  
  // Save users to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  }, [users]);

  const setUser = (user: User) => {
    setCurrentUser(user);
  };

  // const isAdmin = () => currentUser.userRole === "admin";
  const isAdmin = () => currentUser.userRole === "1";

  
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };
  
  // Check if username is already taken (case insensitive)
  // const isUsernameTaken = (username: string): boolean => {
  //   return users.some(user => 
  //     user.username?.toLowerCase() === username.toLowerCase()
  //   );
  // };
  
  // User management (admin only)
  // const addUser = (userData: Omit<User, "id">) => {
  //   if (!isAdmin() && users.length > 0) {
  //     toast({
  //       variant: "destructive",
  //       title: "Access Denied",
  //       description: "Only administrators can add users"
  //     });
  //     return;
  //   }
    
  //   // Check if username is already taken
  //   if (userData.username && isUsernameTaken(userData.username)) {
  //     toast({
  //       variant: "destructive",
  //       title: "Username Unavailable",
  //       description: "This username is already taken. Please choose another one."
  //     });
  //     throw new Error("Username already taken");
  //   }
    
  //   const newUser: User = {
  //     ...userData,
  //     id: `user-${users.length + 1}`
  //   };
    
  //   setUsers(prev => [...prev, newUser]);
    
  //   toast({
  //     title: "User Added",
  //     description: `${newUser.firstName} has been added as a ${newUser.userRole} user`
  //   });
  // };
  
  // Remove isUsernameTaken

  
const addUser = (userData: Omit<User, "id">) => {
  if (!isAdmin() && users.length > 0) {
    toast({
      variant: "destructive",
      title: "Access Denied",
      description: "Only administrators can add users"
    });
    return;
  }

  const newUser: User = {
    ...userData,
    id: `user-${users.length + 1}`
  };

  setUsers(prev => [...prev, newUser]);

  toast({
    title: "User Added",
    description: `${newUser.firstName} has been added as a ${newUser.userRole} user`
  });
};

const isAuthenticated = () => !!currentUser && !!currentUser.id;


  const removeUser = (userId: string) => {
    if (!isAdmin()) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "Only administrators can remove users"
      });
      return;
    }
    
    // Never allow removing the current user or the last admin
    if (userId === currentUser.id) {
      toast({
        variant: "destructive",
        title: "Action Denied",
        description: "You cannot remove yourself"
      });
      return;
    }
    
    const userToRemove = users.find(u => u.id === userId);
    if (!userToRemove) return;
    
    // Check if this is the last admin
    if (userToRemove.userRole === "admin" && users.filter(u => u.userRole === "admin").length <= 1) {
      toast({
        variant: "destructive",
        title: "Action Denied",
        description: "Cannot remove the last administrator"
      });
      return;
    }
    
    setUsers(prev => prev.filter(u => u.id !== userId));
    
    toast({
      title: "User Removed",
      description: `${userToRemove.firstName} has been removed`
    });
  };

  return (
    <UserContext.Provider value={{ 
      currentUser, 
      setUser, 
      isAdmin, 
      isDarkMode, 
      toggleDarkMode,
      users,
      addUser,
      removeUser,
      isAuthenticated,
      // isUsernameTaken,
    }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error("useUser must be used within a UserProvider");
  }
  return context;
};
